<?php

$name = "Eko";
$age = 30;

echo "Name : ";
echo $name;
echo "\n";

echo "Age : ";
echo $age;
echo "\n";


$contoh = "eko";
$$contoh = "kurniawan";

echo "Contoh : ";
echo $contoh;
echo "\n";

echo "eko : ";
echo $eko;
echo "\n";
