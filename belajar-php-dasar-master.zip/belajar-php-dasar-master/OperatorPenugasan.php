<?php

$total = 0;

$fruit = 5000;
$chicken = 10000;
$orangeJuice = 5000;


$total += $fruit;
$total += $chicken;
$total += $orangeJuice;

var_dump($total);