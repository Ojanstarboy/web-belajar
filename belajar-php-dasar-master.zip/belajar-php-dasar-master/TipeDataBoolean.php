<?php

echo "Benar : ";
var_dump(true);

echo "Salah : ";
var_dump(false);
