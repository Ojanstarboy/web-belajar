<?php

$gender = "PRIA";
$hi = $gender == "PRIA" ? "Hi bro!" : "Hi nona!";

echo $hi . PHP_EOL;
