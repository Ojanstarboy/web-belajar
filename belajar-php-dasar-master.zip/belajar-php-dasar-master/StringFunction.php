<?php

var_dump(join(",", [10, 11, 12, 13, 14, 15]));
var_dump(explode(" ", "Eko Kurniawan Khanendy"));
var_dump(strtolower("EKO KURNIAWNA KHANNEDY"));
var_dump(strtoupper("eko kurniawna khannedy"));
var_dump(trim("        eko      kurniawan       "));
var_dump(substr("Eko Kurniawan Khannedy", 0, 3));