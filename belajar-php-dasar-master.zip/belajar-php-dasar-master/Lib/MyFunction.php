<?php

function sayHello(string $firstName, string $lastName): string
{
    return "Hello $firstName $lastName";
}
