<?php

/*
Ini adalah function untuk menampilkan
tulisan say hello
 */
function sayHello()
{
    // ini komentar satu baris
    echo "Hello" . PHP_EOL;
}

sayHello();
