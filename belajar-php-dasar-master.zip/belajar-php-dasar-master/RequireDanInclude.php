<?php
include_once "Lib/MyFunction.php";
include_once "Lib/MyFunction.php";

echo sayHello("Eko", "Kurniawan");

